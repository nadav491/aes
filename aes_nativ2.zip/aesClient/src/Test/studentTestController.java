package Test;

import client.ActionsType;
import client.ActionsType.ActionNumber;
import client.ChatClient;
import client.Client;
import message.MessageType;

public class studentTestController {

	public static void submitStudentTest(studentTest std_test, ChatClient client)
	{
		MessageType msg = new MessageType(ActionsType.getValue(ActionNumber.STUDENT_TEST_CREATE), std_test);
		client.handleMessageFromClientUI(msg);
	}
	public static void getAllTestsOfStudentByStudentID(String std_id, ChatClient client)
	{
		MessageType msg = new MessageType(ActionsType.getValue(ActionNumber.STUDENT_TEST_GET_ALL_TESTS), std_id);
		client.handleMessageFromClientUI(msg);
	}
}
